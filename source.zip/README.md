# Alex Cave Dimensions（6合1 · Fabric 1.21.1）

针对 **Alex's Caves Continued 1.1.1** 的 6 合 1 模组（**v1.1.0 专属洞穴特效最终版**）：

1. **自动关闭 ACC 在主世界的洞穴生成**（服务端启动前改写
   `config/alexscaves_biome_generation/*.json` 的 `disabled_completely=true`），
   新存档/新区域不再生成 Alex 洞穴，与 RTF 高度调整、YUNG 洞穴等主世界生成模组完全隔离；
2. **6 个单一洞穴生物群系维度**，每个维度使用**专属洞穴噪声地形**（galena / radrock /
   limestone / abyssmarine / coprolith / 巧克力等 ACC 原生方块做地层），
   生物群系的地形、矿物、结构、刷怪、音效、粒子、雾色水色全部原样继承；
3. **ACC 专属机制特效自动生效**——磁力拉扯、毒气伤害、糖果低重力、渊海水压、辐射等
   按"玩家所在生物群系 tag"判断（见下方原理），固定生物群系的维度内无需任何代码自动触发；
4. **地图模组即插即用**——维度为标准原版维度，Xaero's World Map / Minimap、JourneyMap
   自动识别并可一键 TP，中文维度名经 lang 文件提供；
5. **无 Mixin、零依赖侵入**——纯数据包 + 标准库文件读写，与 ACC 自身 100+ mixin 零冲突。

## 功能对照

| 需求 | 实现 |
| --- | --- |
| 关闭 ACC 主世界生成（建档前） | 服务端启动前改写 ACC 生物群系生成配置（`disabled_completely=true`），生物群系仍注册 |
| 6 个单一生物群系维度 | `data/alexdim/dimension/*.json`：`minecraft:noise` 生成器 + `biome_source: fixed` 锁定单一群系 |
| 极致还原地形 | 每洞专属 `worldgen/noise_settings/*.json`（洞穴噪声 + ACC 原生方块地层，源自 MIT 参考实现） |
| 专属洞穴特效（磁力/毒气/失重/水压/辐射） | 自动生效：ACC 特效按生物群系 tag 判断（详见「特效原理」） |
| 生物刷怪 | 生物群系 spawners 数据驱动 + `natural: true`，维度内正常刷怪 |
| 地图模组识别 + 一键 TP | 标准原版维度注册，Xaero/JourneyMap 自动收录；中文名 `dimension.alexdim.*` |
| 缺前置报错 | `fabric.mod.json` depends：fabricloader / fabric-api / minecraft / java / alexscaves |
| 前置更新不炸存档 | 仅依赖生物群系 ID 与配置文件字段；字段缺失/格式变化时自动降级跳过并打日志 |
| 无 mixin 冲突 | 零 mixin，仅数据包 + 标准库文件读写 |

## 前置依赖（必须安装）

| 模组 | 版本要求 | 说明 |
| --- | --- | --- |
| Minecraft | 1.21.1 | — |
| Fabric Loader | 0.16.x 或更新 | 1.21.1 需要 Java 21 |
| Fabric API | ≥0.116.15（实测 0.116.17+1.21.1） | ACC 1.1.1 官方要求 |
| Alex's Caves Continued | 1.1.1（`alexscaves-1.1.1-fabric+1.21.1.jar`） | 同时需要其依赖 **CodxLib ≥1.3.6**（实测 1.6.1） |
| Alex's Mobs Continued | 2.2.2（可选但推荐） | 生物联动 |
| Xaero's World Map / Minimap 或 JourneyMap | 任意（推荐） | 地图 TP 与维度切换 |

> 本模组**不需要 TerraBlender**（ACC 1.1.1 本身也不依赖它；用户整合包中的
> `TerraBlender-fabric-1.21.1-4.1.0.8` 可保留，不影响本模组）。

## 特效原理（为什么维度内自动生效）

对 ACC 1.1.1 内部代码的实测分析结论：

- ACC 的专属机制特效（磁力拉扯 `MagnetUtil`、毒气伤害、糖果低重力、渊海水压、辐射、
  环境粒子、专属音乐/环境音覆盖）全部通过**生物群系 tag** 判断玩家所在生物群系
  （`ACTagRegistry` + `data/alexscaves/tags/worldgen/biome/*.json`，
  如 `alexscaves:alexs_caves_biomes`），**与维度无关**；
- 本模组的每个维度把整个维度的生物群系**固定**为对应的 `alexscaves:*` 洞穴生物群系，
  玩家进入即命中 ACC 的生物群系判断 → 特效自动触发；
- 生物群系刷怪（spawners / spawn_costs）与结构（magnetic_ruins 等）同为生物群系数据驱动，
  维度设 `natural: true` 后正常生成，ACC 的刷怪拦截按生物群系判断（洞穴生物群系外才拦截），
  全洞穴生物群系的维度内不受影响；
- 因此**无需反射、无需 Access Widener、无需 Mixin**，即可获得与主世界洞穴一致的
  视觉效果与机制体验。这是「无冲突」与「极致还原」能同时成立的原因。

## 构建（需要 JDK 21）

```bash
# 方式 A：IntelliJ IDEA 打开工程目录，Gradle 同步后运行 build
# 方式 B：命令行（JDK 21 + Gradle 8.x，或使用 gradlew wrapper）
gradle build
```

产物：`build/libs/alexcave-dimensions-1.1.0.jar`

> 版本矩阵已按整合包实测锁定：yarn 1.21.1+build.3、loader 0.16.9、
> fabric-api 0.116.17+1.21.1。若拉取依赖失败，检查网络与 Gradle 仓库代理。

## 安装与使用

1. 把构建出的 jar 放入 `.minecraft/mods/`（连同 Fabric API、ACC、CodxLib）。
2. **第一次启动**：进入主菜单即会触发本模组的禁用逻辑（服务端启动前执行），
   日志中 `[alexdim]` 会显示已关闭 6 个生物群系的主世界生成。
3. **新建存档**（旧存档的新区块同样不再生成 Alex 洞穴；旧区块不受影响）。
4. 验证主世界：`/acc biomes` 应显示 6 个洞穴生物群系全部关闭。
5. 验证维度：
   ```
   /execute in alexdim:magnetic_caves run tp @s 0 80 0
   /execute in alexdim:toxic_caves run tp @s 0 80 0
   ```
6. 打开 Xaero/JourneyMap：维度列表出现 6 个中文名维度，可切换并一键 TP。

## 6 个维度

| 维度 ID | 生物群系 | 中文名 | 地层方块（noise_settings） |
| --- | --- | --- | --- |
| `alexdim:magnetic_caves` | `alexscaves:magnetic_caves` | 磁力洞穴 | galena / energized_galena |
| `alexdim:primordial_caves` | `alexscaves:primordial_caves` | 原始洞穴 | limestone / amber / 草皮 |
| `alexdim:toxic_caves` | `alexscaves:toxic_caves` | 毒性洞穴 | radrock / unrefined_waste |
| `alexdim:abyssal_chasm` | `alexscaves:abyssal_chasm` | 渊海陷窟 | abyssmarine / muck（海平面 127） |
| `alexdim:forlorn_hollows` | `alexscaves:forlorn_hollows` | 异寂空谷 | coprolith / guanostone |
| `alexdim:candy_cavity` | `alexscaves:candy_cavity` | 糖果龋洞 | 巧克力块 / cake_layer |

## 已知边界（如实说明）

- **配置是全局的**：主世界生成关闭对所有存档生效（符合"建档前关闭"需求）；
  旧存档已生成的 Alex 洞穴区块不受影响（预期行为）。
- **维度无天空**：`has_skylight=false`、`has_ceiling=true`，与地下洞穴一致；
  传送进入时若出生在实心方块内会卡住，用 `tp @s 0 80 0` 这类坐标进入。
- **ACC 更新兼容**：若 ACC 后续版本改变配置字段名，本模组自动降级为"跳过+警告"，
  不会崩溃；届时需按新字段手动关闭（或反馈本模组更新）。
- **刷怪实测**：机制上维度内生物群系 spawners 生效；若个别洞穴生物（如渊海特有生物）
  行为异常，与 ACC 对特定生物群系的逻辑有关，可在游戏内反馈复现步骤。

## 工程结构

```
src/main/
├── java/com/alexdim/
│   ├── AlexCaveDimensions.java      # 入口：SERVER_STARTING 时调用配置禁用器
│   └── AccCaveConfigManager.java    # 改写 ACC 生物群系生成配置（幂等、容错）
└── resources/
    ├── fabric.mod.json              # 依赖声明（缺前置报错）
    ├── assets/alexdim/lang/zh_cn.json   # 6 个中文维度名
    └── data/alexdim/
        ├── dimension_type/{6个生物群系}.json   # natural=true 等参数
        ├── dimension/{6个生物群系}.json        # noise + fixed biome
        └── worldgen/noise_settings/{6个生物群系}.json  # 洞穴噪声 + 原生方块地层
```

## 许可与参考

- 本模组 MIT 许可；`noise_settings` 地形参数参考 MIT 项目
  [vcwdfca/Alex-Caves-Dimension](https://github.com/vcwdfca/Alex-Caves-Dimension)
  （原作者 mrqx0195，1.20.1 Forge 原版，1.21.1 NeoForge 移植）的已发布数据。
- ACC 生物群系 ID / 配置字段 / tag 机制均来自对 `alexscaves-1.1.1-fabric+1.21.1.jar`
  内部代码与数据文件的实测分析（LGPL-3.0 模组，本模组不包含其代码）。

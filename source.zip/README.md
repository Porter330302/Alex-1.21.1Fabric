# Alex's Caves Dimensions（Alex 洞穴维度）· v1.2.0 · Fabric 1.21.1

> 把 Alex's Caves Continued 的 6 大洞穴生物群系做成 **7 个独立维度** 的模组：
> **6 个单一洞穴生物群系维度** + **1 个全群系混合维度（caves_all）**。
> 纯数据包实现、零 Mixin、AC 专属机制特效自动生效，地图模组即插即用。

---

## 目录

1. [特性一览](#特性一览)
2. [7 维度总览](#7-维度总览)
3. [维度参数总表（可参考/借鉴的核心）](#维度参数总表)
4. [第 7 维度 caves_all 详解](#第-7-维度-caves_all-详解)
5. [表面规则精细化参数](#表面规则精细化参数)
6. [技术原理](#技术原理)
7. [前置依赖](#前置依赖)
8. [使用说明](#使用说明)
9. [已知限制与取舍](#已知限制与取舍)
10. [构建（源码 → jar）](#构建源码--jar)
11. [参考与致谢](#参考与致谢)

---

## 特性一览

- **7 个维度**：6 个单一生物群系维度（磁力 / 原始 / 毒性 / 渊海 / 异寂 / 糖果）+ 1 个全群系混合维度 `caves_all`（multi_noise 区域化）；
- **极致还原**：每个维度沿用 AC 原版洞穴生成逻辑（原版 `overworld/sloped_cheese` 密度函数），生物群系的方块、矿物、结构、刷怪、音效、粒子、雾色水色**全部原样继承**；
- **AC 专属机制特效自动触发**：磁力拉扯、毒气伤害、糖果低重力、渊海水压、辐射——按"玩家所在生物群系"判断，固定群系维度内**无需任何代码**自动生效；
- **自动隔离 AC 主世界生成**：服务端启动时把 AC 的生物群系生成配置改写为 `disabled_completely=true`，避免与 RTF、YUNG 等主世界地形模组冲突（可恢复，见「已知限制」）；
- **地图模组即插即用**：标准原版维度注册，Xaero's World Map / Minimap、JourneyMap 自动识别；**中英双语维度名**（`zh_cn.json` + `en_us.json`）；
- **零 Mixin、依赖守卫**：与 ACC 自身 100+ mixin 零冲突；启动时校验全部依赖方块/生物群系/流体，缺失时醒目警告、不阻止启动、不碰存档。

---

## 7 维度总览

| # | 维度 ID | 类型 | 对应 AC 生物群系 | 一句话 |
|---|---------|------|-----------------|--------|
| 1 | `alexdim:magnetic_caves` | 单一群系 | `alexscaves:magnetic_caves` | 磁石洞穴，红蓝钕节点，磁力吸铁 |
| 2 | `alexdim:primordial_caves` | 单一群系 | `alexscaves:primordial_caves` | 石灰岩洞穴，草皮条带，琥珀 |
| 3 | `alexdim:toxic_caves` | 单一群系 | `alexscaves:toxic_caves` | 放射岩洞穴，**酸液海**，辐射伤害 |
| 4 | `alexdim:abyssal_chasm` | 单一群系 | `alexscaves:abyssal_chasm` | **整维大海**（水位127），水下生物群 |
| 5 | `alexdim:forlorn_hollows` | 单一群系 | `alexscaves:forlorn_hollows` | 粪石洞穴，浅水（水位47），异寂氛围 |
| 6 | `alexdim:candy_cavity` | 单一群系 | `alexscaves:candy_cavity` | 巧克力洞穴，**整片汽水海**，低重力 |
| 7 | `alexdim:caves_all` | **多群系混合** | multi_noise × 6 | 6 大洞穴生物群系按噪声区域化镶嵌成一整个世界 |

---

## 维度参数总表

> 这张表是**全部维度配置的速查手册**，改参数 = 改对应 JSON，重新打包即可。

### 1~6：单一生物群系维度

| 维度 | 生物群系 (fixed) | sea_level | default_fluid | default_block | 高度范围 | 表面规则要点 |
|------|-----------------|-----------|---------------|---------------|---------|-------------|
| magnetic_caves | alexscaves:magnetic_caves | 63 | water | galena | -64 ~ 320 | 地表层 energized_galena_neutral + 红/蓝钕节点散布 |
| primordial_caves | alexscaves:primordial_caves | 50 | water | limestone | -64 ~ 320 | 草皮条带（±0.25 阈值）+ 琥珀层 |
| toxic_caves | alexscaves:toxic_caves | 63 | **acid** | radrock | -64 ~ 320 | 放射岩地层 + 未精炼废料 |
| abyssal_chasm | alexscaves:abyssal_chasm | **127** | water | abyssmarine | -64 ~ 320 | 深渊石地层，水下生物群 feature |
| forlorn_hollows | alexscaves:forlorn_hollows | **47** | water | coprolith | -64 ~ 320 | 粪石地层 + 鸟粪石/多孔粪石 |
| candy_cavity | alexscaves:candy_cavity | 63 | **purple_soda** | block_of_chocolate | -64 ~ 320 | 巧克力地层 + 霜糖巧克力/蛋糕层 |

- **水位是各维度专属的**：深渊 127（大海）、原始 50（浅湖）、荒芜 47（更浅）、其余 63；
- **专属流体是整维度生效的**：糖果维度水位以下**全部是紫色汽水**，剧毒维度水位以下**全部是酸液**（由 `default_fluid` 决定，非 surface_rule 覆盖）；
- **所有单一维度**共用 `dimension_type` 模板：ambient_light=1、has_ceiling=true、无天光、min_y=-64、height=384、effects=overworld。

### 7：caves_all（多群系混合维度）

| 参数 | 值 |
|------|-----|
| biome_source | `minecraft:multi_noise`（6 群系区域化） |
| sea_level | 63（统一） |
| default_fluid | water（各群系水域由 surface_rule 覆盖为专属流体） |
| default_block | stone（各群系区域由 surface_rule 分派方块） |
| 高度范围 | **-128 ~ 336**（height=464，深渊水下 191 格 = 与单独深渊维度一致） |

---

## 第 7 维度 caves_all 详解

### multi_noise 群系参数（区域化质心）

6 个群系在"温度 × 湿度"参数空间散开，形成**连续色块区域**（Voronoi 细胞，数百格见方）：

| 生物群系 | temperature | humidity | offset | 所在气候区 |
|---------|-------------|----------|--------|-----------|
| magnetic_caves | 0.0 | 0.0 | 0.0 | 中性 |
| primordial_caves | -1.0 | +0.5 | 0.1 | 冷湿 |
| toxic_caves | +0.6 | -0.6 | 0.2 | 热干 |
| abyssal_chasm | -0.3 | -0.8 | 0.3 | 冷湿(深) |
| forlorn_hollows | -0.8 | -0.5 | 0.4 | 冷干 |
| candy_cavity | +1.0 | +1.0 | 0.5 | 热湿 |

> 原理：每个区块由原版气候噪声采样出参数点，归属最近的群系质心 → 6 种洞穴环境随机镶嵌、**全覆盖无留白**，色块内整根垂直柱子都是该群系。

### 按群系分派的 surface_rule 结构

```
sequence:
  1. bedrock_floor（基岩层，随 min_y 自适应）
  2. above_preliminary_surface → 按 biome 分派：
     ├─ candy_cavity → 水域 191 层紫色汽水 + 巧克力地层
     ├─ toxic_caves → 水域 191 层酸液 + 放射岩地层
     ├─ magnetic_caves → 水域水 + 磁石地层(含节点散布)
     ├─ primordial_caves → 水域水 + 石灰岩地层(草皮条带)
     ├─ abyssal_chasm → 水域水 + 深渊石地层
     └─ forlorn_hollows → 水域水 + 粪石地层
```

- **专属流体全深度覆盖**：糖果/剧毒区从水面（y=63）到基岩（y=-128）共 **191 层**全部是汽水/酸液（191 条 water 条件逐层覆盖）；
- **方块整柱生效**：每个区域的洞壁/洞底全部是该群系的原生方块；
- **机制特效自动生效**：磁力吸铁、毒气伤害、低重力、水压、辐射按区域自动触发。

---

## 表面规则精细化参数

新增了两个自定义密度函数，用于复刻 AC 原版的地表分布质感（`data/alexdim/worldgen/density_function/`）：

| 函数 | 噪声 | xz_scale | 用途 |
|------|------|----------|------|
| `alexdim:stripe` | `minecraft:temperature` | 0.12 | 原始洞穴**草皮条带**：条带内 grass_block、条带外 dirt（阈值 ±0.25） |
| `alexdim:scatter` | `minecraft:vegetation` | 2.5 | 磁力洞穴**节点散布**：scarlet 节点 0.62~0.66、azure 节点 0.80~0.84 |

---

## 技术原理

### 1. 纯数据包实现，零 Mixin

全部功能由标准原版注册表完成：

```
data/alexdim/
├── dimension/*.json           维度定义（generator + biome_source）
├── dimension_type/*.json      维度类型（min_y / height / 光照 / 天花板等）
├── worldgen/noise_settings/*.json  洞穴噪声 + 表面规则（default_fluid / surface_rule）
├── worldgen/density_function/*.json 自定义噪声函数（stripe / scatter）
└── 语言文件 assets/alexdim/lang/{zh_cn,en_us}.json
```

### 2. 洞穴形态 = 原版 cheese（与 AC 原版一致）

反编译 AC 原版 jar 确认：**AC 洞穴挖空用的就是原版 `overworld/sloped_cheese` 密度函数**，AC 没有自己的生成器。本模组沿用同一函数（无地表地形参与，`final_density` 中 continents/erosion/ridges/depth 参与次数为 0），得到与 AC 一致的"巨型奶酪洞穴空腔"。

### 3. AC 专属机制特效为什么自动生效

AC 的磁力拉扯（MagnetUtil）、毒气伤害、糖果低重力、渊海水压、辐射、环境粒子、专属音乐等全部通过**生物群系 tag** 判断玩家所在生物群系（`data/alexscaves/tags/worldgen/biome/*.json`），与维度无关。本模组把维度生物群系固定为对应的 AC 洞穴群系 → 玩家进入即命中判断 → 特效自动触发。刷怪（spawners）与结构（magnetic_ruins 等）同为生物群系数据驱动，维度设 `natural: true` 后正常生成。

### 4. 自动隔离 AC 主世界生成（AccCaveConfigManager）

服务端启动前，把 `config/alexscaves_biome_generation/*.json` 改写为 `disabled_completely=true`，使 AC 洞穴不再生成于主世界，与 RTF 高度调整、YUNG 洞穴等主世界模组完全隔离。**生物群系本身仍注册**，所以维度不受影响。幂等写入，不依赖 AC 内部类。

> ⚠️ **副作用与恢复**：这是持久配置。卸载本模组后 AC 主世界洞穴仍处于关闭状态，需手动把上述 JSON 改回 `disabled_completely=false`（或删除该目录）恢复。

### 5. 依赖守卫（AccDependencyGuard）

启动时校验：7 维度引用的全部生物群系、表面方块、专属流体是否仍注册（覆盖 AC 更新/改名场景）。缺失时输出醒目中文警告、**不阻止启动、不碰存档**。API 使用 yarn 1.21.1+build.3 官方映射验证。

---

## 前置依赖

| 模组 | 版本要求 | 说明 |
|------|---------|------|
| Minecraft | 1.21.1 | — |
| Fabric Loader | ≥ 0.16.x | 1.21.1 需要 Java 21 |
| Fabric API | ≥ 0.116.15（实测 0.116.17+1.21.1） | AC Continued 1.1.1 官方要求 |
| Alex's Caves Continued | 1.1.1 | 同时需要其依赖 **CodxLib ≥ 1.3.6**（实测 1.6.1） |
| Alex's Mobs Continued | 2.2.2（可选但推荐） | 生物联动 |
| Xaero's World Map / Minimap 或 JourneyMap | 任意（推荐） | 地图 TP 与维度切换 |

> 不需要 TerraBlender。`fabric.mod.json` 的 `depends` 对 alexscaves 为 `>=1.1.1` 无上限（已接受 AC 大版本更新风险，守卫兜底）；`suggests` 包含 alexsmobs 与三款地图模组。

---

## 使用说明

进维度（无需地图模组，命令直接传送）：

```mcfunction
# 单一维度
/execute in alexdim:magnetic_caves run tp @s 0 120 0
/execute in alexdim:primordial_caves run tp @s 0 120 0
/execute in alexdim:toxic_caves run tp @s 0 120 0
/execute in alexdim:abyssal_chasm run tp @s 0 100 0   # 大海，建议 y=100+ 出生
/execute in alexdim:forlorn_hollows run tp @s 0 100 0
/execute in alexdim:candy_cavity run tp @s 0 120 0

# 全群系混合维度（六合一）
/execute in alexdim:caves_all run tp @s 0 120 0
```

地图模组（Xaero/JourneyMap）安装后自动显示维度名并支持一键切换。

---

## 已知限制与取舍

1. **第 7 维度水位统一**：multi_noise 维度只有一个 sea_level（63），无法按群系动态水位。深渊区 191 格深水已与单独维度一致；原始/荒芜区水域略深于单独维度（视为彩蛋）。
2. **深水流体覆盖成本**：糖果/剧毒区 191 层逐层覆盖，深水方块匹配链略长；实测若加载变慢可降为浅层覆盖（修改 offset 层数）。
3. **AC 更新兼容**：依赖 alexscaves 无上界；AC 若移除生物群系/方块，守卫会警告但不阻止启动，存档不受损（缺失群系/方块的维度进入时由原版容错处理）。
4. **AC 主世界关闭为持久副作用**：卸载后需手动恢复（见上）。
5. **色块粒度不可调**：multi_noise 使用原版固定气候噪声，区域大小为数百格见方，无法直接调整。

---

## 构建（源码 → jar）

本模组支持 GitHub Actions 云端编译：

1. 把本目录**全部内容**压缩为 `source.zip`（解压后 `build.gradle` 必须在根目录，含 gradlew/gradle wrapper）；
2. 上传到 GitHub 仓库根目录，工作流 `unzip -o source.zip || true` → `./gradlew build` → 上传 `build/libs/*.jar`；
3. 下载产物 jar 放入 `mods/`。

本地构建：`gradle wrapper` 后 `./gradlew build`（产物 `build/libs/alexcave-dimensions-1.2.0.jar`）。

---

## 参考与致谢

- 参考实现：Dimensions of AC（1.20.1/1.21.1）、dimension_of_caves（均为单一群系维度，本模组 7 维度方案为原创扩展）；
- AC 生成机制结论来自对 `alexscaves-1.1.1-fabric+1.21.1.jar` 的反编译分析（ACSurfaceRules / MultiNoiseBiomeSourceMixin / NoiseGeneratorSettingsMixin）；
- 依赖 yarn 1.21.1+build.3 官方映射验证 API。

MIT License.

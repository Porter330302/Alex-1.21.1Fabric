# Alex's Caves Dimensions · v1.2.0 · Fabric 1.21.1

> Turns Alex's Caves Continued's 6 cave biomes into **7 standalone dimensions**:
> **6 single-biome dimensions** + **1 all-biomes mixed dimension (`caves_all`)**.
> Pure datapack, zero Mixins, AC mechanics auto-trigger, minimap-ready.

---

## Table of Contents

1. [Features](#features)
2. [Dimension Overview](#dimension-overview)
3. [Dimension Parameter Reference (core for remixing)](#dimension-parameter-reference)
4. [caves_all — the 7th Dimension](#caves_all--the-7th-dimension)
5. [Surface Rule Fine-Tuning](#surface-rule-fine-tuning)
6. [How It Works](#how-it-works)
7. [Dependencies](#dependencies)
8. [Usage](#usage)
9. [Known Limitations & Trade-offs](#known-limitations--trade-offs)
10. [Building (source → jar)](#building-source--jar)
11. [References & Credits](#references--credits)

---

## Features

- **7 dimensions**: 6 single-biome dimensions (Magnetic / Primordial / Toxic / Abyssal / Forlorn / Candy) + 1 mixed dimension `caves_all` (multi_noise, region-based);
- **Faithful to AC**: every dimension reuses the vanilla `overworld/sloped_cheese` density function (the same one AC's caves are carved with); biomes' blocks, ores, structures, spawns, sounds, particles, fog and water tint are all inherited as-is;
- **AC mechanics auto-trigger**: magnet pull, toxic gas damage, candy low gravity, abyssal water pressure, radiation — AC checks the player's biome via tags, so fixed-biome dimensions trigger them with zero code;
- **AC overworld isolation**: on server start the mod rewrites AC's biome generation config to `disabled_completely=true`, keeping it isolated from RTF / YUNG-style overworld terrain mods (recoverable — see Limitations);
- **Minimap-ready**: standard vanilla dimension registration; Xaero's World Map / Minimap and JourneyMap pick them up automatically; **bilingual dimension names** (`zh_cn.json` + `en_us.json`);
- **Zero Mixins + dependency guard**: no conflicts with AC's 100+ mixins; on startup it validates every referenced biome / block / fluid and warns loudly if missing — without blocking the server or touching saves.

---

## Dimension Overview

| # | Dimension ID | Type | AC Biome | Description |
|---|--------------|------|----------|-------------|
| 1 | `alexdim:magnetic_caves` | single | `alexscaves:magnetic_caves` | Galena caves, scarlet/azure nodes, magnet pull |
| 2 | `alexdim:primordial_caves` | single | `alexscaves:primordial_caves` | Limestone caves, grass stripes, amber |
| 3 | `alexdim:toxic_caves` | single | `alexscaves:toxic_caves` | Radrock caves, **acid ocean**, radiation damage |
| 4 | `alexdim:abyssal_chasm` | single | `alexscaves:abyssal_chasm` | **Full-dimension ocean** (sea level 127), underwater biomes |
| 5 | `alexdim:forlorn_hollows` | single | `alexscaves:forlorn_hollows` | Coprolith caves, shallow water (sea level 47) |
| 6 | `alexdim:candy_cavity` | single | `alexscaves:candy_cavity` | Chocolate caves, **full soda ocean**, low gravity |
| 7 | `alexdim:caves_all` | **mixed** | multi_noise × 6 | All 6 AC cave biomes regionally interleaved into one world |

---

## Dimension Parameter Reference

> Quick reference for every dimension config. To tweak a parameter, edit the corresponding JSON and rebuild.

### 1–6: Single-Biome Dimensions

| Dimension | Biome (fixed) | sea_level | default_fluid | default_block | Height range | Surface-rule highlights |
|-----------|---------------|-----------|---------------|---------------|--------------|-------------------------|
| magnetic_caves | alexscaves:magnetic_caves | 63 | water | galena | -64 ~ 320 | energized_galena_neutral floor + scarlet/azure node scatter |
| primordial_caves | alexscaves:primordial_caves | 50 | water | limestone | -64 ~ 320 | grass stripes (±0.25 threshold) + amber |
| toxic_caves | alexscaves:toxic_caves | 63 | **acid** | radrock | -64 ~ 320 | radrock strata + unrefined waste |
| abyssal_chasm | alexscaves:abyssal_chasm | **127** | water | abyssmarine | -64 ~ 320 | abyssmarine strata, underwater biome features |
| forlorn_hollows | alexscaves:forlorn_hollows | **47** | water | coprolith | -64 ~ 320 | coprolith strata + guano/guanostone |
| candy_cavity | alexscaves:candy_cavity | 63 | **purple_soda** | block_of_chocolate | -64 ~ 320 | chocolate strata + frosted chocolate/cake layer |

- **Sea levels are dimension-specific**: Abyssal 127 (ocean), Primordial 50 (shallow lake), Forlorn 47 (shallower), others 63;
- **Biome fluid is dimension-wide**: everything below sea level in Candy is purple soda, in Toxic it's acid (set by `default_fluid`, not surface rules);
- All single dimensions share the same `dimension_type` template: ambient_light=1, has_ceiling=true, no skylight, min_y=-64, height=384, effects=overworld.

### 7: caves_all (Mixed Dimension)

| Parameter | Value |
|-----------|-------|
| biome_source | `minecraft:multi_noise` (6 biomes, regionalized) |
| sea_level | 63 (uniform) |
| default_fluid | water (each region's water is overridden by surface rules with its own fluid) |
| default_block | stone (each region's blocks are assigned by surface rules) |
| Height range | **-128 ~ 336** (height=464; Abyssal water depth 191 blocks = same as the dedicated Abyssal dimension) |

---

## caves_all — the 7th Dimension

### multi_noise Biome Parameters (regional centroids)

The 6 biomes are spread across the temperature × humidity parameter space, forming continuous color-block regions (Voronoi cells, a few hundred blocks across):

| Biome | temperature | humidity | offset | Climate zone |
|-------|-------------|----------|--------|--------------|
| magnetic_caves | 0.0 | 0.0 | 0.0 | Neutral |
| primordial_caves | -1.0 | +0.5 | 0.1 | Cold & wet |
| toxic_caves | +0.6 | -0.6 | 0.2 | Hot & dry |
| abyssal_chasm | -0.3 | -0.8 | 0.3 | Cold & wet (deep) |
| forlorn_hollows | -0.8 | -0.5 | 0.4 | Cold & dry |
| candy_cavity | +1.0 | +1.0 | 0.5 | Hot & wet |

> How it works: each chunk samples a parameter point from the vanilla climate noises and is assigned to the nearest biome centroid → the 6 cave environments are interleaved with **full coverage, no gaps**; inside each region the whole vertical column is that biome.

### Per-Biome surface_rule Structure

```
sequence:
  1. bedrock_floor (adapts to min_y)
  2. above_preliminary_surface → dispatched by biome:
     ├─ candy_cavity → 191 layers of purple soda water + chocolate strata
     ├─ toxic_caves → 191 layers of acid water + radrock strata
     ├─ magnetic_caves → water + galena strata (with node scatter)
     ├─ primordial_caves → water + limestone strata (grass stripes)
     ├─ abyssal_chasm → water + abyssmarine strata
     └─ forlorn_hollows → water + coprolith strata
```

- **Full-depth biome fluid**: in Candy/Toxic regions, from the water surface (y=63) down to bedrock (y=-128), all **191 layers** are purple soda / acid (191 per-layer water conditions);
- **Blocks run the full column**: every wall/floor block in a region is that biome's native block;
- **Mechanics auto-trigger per region**: magnet pull, toxic gas, low gravity, water pressure, radiation.

---

## Surface Rule Fine-Tuning

Two custom density functions replicate AC's original surface-distribution feel (`data/alexdim/worldgen/density_function/`):

| Function | Noise | xz_scale | Purpose |
|----------|-------|----------|---------|
| `alexdim:stripe` | `minecraft:temperature` | 0.12 | Primordial **grass stripes**: grass_block inside the band, dirt outside (±0.25 threshold) |
| `alexdim:scatter` | `minecraft:vegetation` | 2.5 | Magnetic **node scatter**: scarlet 0.62–0.66, azure 0.80–0.84 |

---

## How It Works

### 1. Pure datapack, zero Mixins

Everything uses standard vanilla registries:

```
data/alexdim/
├── dimension/*.json           dimension definitions (generator + biome_source)
├── dimension_type/*.json      dimension types (min_y / height / lighting / ceiling etc.)
├── worldgen/noise_settings/*.json  cave noise + surface rules (default_fluid / surface_rule)
├── worldgen/density_function/*.json custom noise functions (stripe / scatter)
└── lang assets/alexdim/lang/{zh_cn,en_us}.json
```

### 2. Cave shape = vanilla cheese (same as AC)

Decompiling the AC jar confirmed: **AC caves are carved with the vanilla `overworld/sloped_cheese` density function** — AC has no custom generator. This mod uses the same function (continents/erosion/ridges/depth never contribute in `final_density`), yielding the same giant cheese-cave chambers.

### 3. Why AC mechanics auto-trigger

AC's magnet pull (MagnetUtil), toxic gas, candy low gravity, abyssal water pressure, radiation, ambient particles and music are all dispatched by **biome tags** (`data/alexscaves/tags/worldgen/biome/*.json`), independent of dimension. Fix the dimension's biome to an AC cave biome → the player's biome matches → mechanics fire. Spawns and structures (magnetic_ruins etc.) are biome-driven too and work with `natural: true`.

### 4. AC overworld isolation (AccCaveConfigManager)

On server start, rewrites `config/alexscaves_biome_generation/*.json` to `disabled_completely=true` so AC caves no longer generate in the overworld — isolated from RTF height adjustments, YUNG caves etc. **Biomes themselves stay registered**, so dimensions are unaffected. Idempotent, no dependency on AC internals.

> ⚠️ **Side effect & recovery**: this is persistent. After uninstalling this mod, AC overworld caves stay disabled until you manually set `disabled_completely=false` in those JSONs (or delete the directory).

### 5. Dependency guard (AccDependencyGuard)

On startup, validates every biome, surface block and fluid the 7 dimensions reference (covers AC updates/renames). Warns loudly in Chinese, **never blocks startup, never touches saves**. API verified against yarn 1.21.1+build.3 official mappings.

---

## Dependencies

| Mod | Version | Notes |
|-----|---------|-------|
| Minecraft | 1.21.1 | — |
| Fabric Loader | ≥ 0.16.x | 1.21.1 needs Java 21 |
| Fabric API | ≥ 0.116.15 (tested 0.116.17+1.21.1) | required by AC Continued 1.1.1 |
| Alex's Caves Continued | 1.1.1 | also needs **CodxLib ≥ 1.3.6** (tested 1.6.1) |
| Alex's Mobs Continued | 2.2.2 (optional, recommended) | mob crossover |
| Xaero's World Map / Minimap or JourneyMap | any (recommended) | map TP & dimension switching |

> TerraBlender is not needed. `fabric.mod.json` `depends` on alexscaves `>=1.1.1` with no upper bound (AC major-update risk accepted; the guard covers it). `suggests` includes alexsmobs and the three map mods.

---

## Usage

Teleport in (no map mod required):

```mcfunction
# Single dimensions
/execute in alexdim:magnetic_caves run tp @s 0 120 0
/execute in alexdim:primordial_caves run tp @s 0 120 0
/execute in alexdim:toxic_caves run tp @s 0 120 0
/execute in alexdim:abyssal_chasm run tp @s 0 100 0   # ocean — spawn y=100+ recommended
/execute in alexdim:forlorn_hollows run tp @s 0 100 0
/execute in alexdim:candy_cavity run tp @s 0 120 0

# Mixed dimension (all six)
/execute in alexdim:caves_all run tp @s 0 120 0
```

With Xaero/JourneyMap installed, dimension names show automatically and one-click switching works.

---

## Known Limitations & Trade-offs

1. **caves_all has a uniform sea level**: a multi_noise dimension has one sea_level (63); per-biome water levels aren't possible. The Abyssal region's 191-block water depth already matches the dedicated dimension; Primordial/Forlorn regions have slightly deeper water than their dedicated versions (treated as a bonus).
2. **Full-depth fluid cost**: Candy/Toxic use 191 per-layer water conditions; the match chain is longer for deep-water blocks. If chunk loading feels slow, drop to a shallow override (edit the offset layers).
3. **AC update compatibility**: alexscaves is unbounded above; if AC removes biomes/blocks the guard warns but never blocks, and saves are not corrupted (vanilla handles missing biomes gracefully on entry).
4. **AC overworld disable is persistent**: restore manually after uninstall (see above).
5. **Region size is not tunable**: multi_noise uses vanilla climate noises; regions are a few hundred blocks across and can't be resized directly.

---

## Building (source → jar)

Designed for GitHub Actions cloud builds:

1. Zip this directory's **entire content** into `source.zip` (after extraction, `build.gradle` must sit at the root, including gradlew/gradle wrapper);
2. Upload to your GitHub repo root; the workflow runs `unzip -o source.zip || true` → `./gradlew build` → uploads `build/libs/*.jar`;
3. Download the jar into `mods/`.

Local build: `gradle wrapper` then `./gradlew build` (artifact `build/libs/alexcave-dimensions-1.2.0.jar`).

---

## References & Credits

- Reference implementations: Dimensions of AC (1.20.1/1.21.1), dimension_of_caves (all single-biome dimensions; the 7-dimension design here is an original extension);
- AC generation findings come from decompiling `alexscaves-1.1.1-fabric+1.21.1.jar` (ACSurfaceRules / MultiNoiseBiomeSourceMixin / NoiseGeneratorSettingsMixin);
- API verified against yarn 1.21.1+build.3 official mappings.

MIT License.

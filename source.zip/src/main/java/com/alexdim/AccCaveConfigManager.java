package com.alexdim;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 关闭 Alex's Caves Continued 在主世界的生物群系生成。
 *
 * 原理：ACC 的生物群系生成配置位于
 *   .minecraft/config/alexscaves_biome_generation/<生物群系>.json
 * 每个文件包含 "disabled_completely" 字段（false=生成，true=完全禁用）。
 * 本类把这些文件统一改写为 true，生物群系本身仍保持注册，
 * 因此内嵌数据包的 6 个独立维度可以继续引用它们，互不影响。
 *
 * 设计原则：
 *  - 只改目标字段，保留文件其余内容；
 *  - 文件缺失 / 解析失败 / 字段不存在时仅记录日志，绝不崩溃；
 *  - 幂等：已是 true 则跳过；
 *  - 不依赖 ACC 内部类，ACC 版本更新导致配置格式变化时自动降级为"跳过+警告"。
 */
public final class AccCaveConfigManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("alexdim");
    private static final String CONFIG_SUBDIR = "alexscaves_biome_generation";
    private static final String FIELD = "disabled_completely";

    private static final String[] BIOME_FILES = {
            "magnetic_caves.json",
            "primordial_caves.json",
            "toxic_caves.json",
            "abyssal_chasm.json",
            "forlorn_hollows.json",
            "candy_cavity.json"
    };

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private AccCaveConfigManager() {
    }

    public static void disableAlexCavesOverworldGeneration() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve(CONFIG_SUBDIR);
        if (!Files.isDirectory(dir)) {
            LOGGER.warn("[alexdim] {} 不存在：ACC 可能尚未生成配置（首次启动后自动生成）。" +
                    "本模组将在配置出现后的下一次启动生效。", dir.toAbsolutePath());
            return;
        }

        int disabled = 0;
        for (String file : BIOME_FILES) {
            if (disableOne(dir.resolve(file))) {
                disabled++;
            }
        }
        LOGGER.info("[alexdim] Alex's Caves 主世界生成检查完成：已确认关闭 {} 个生物群系。", disabled);
    }

    private static boolean disableOne(Path file) {
        if (!Files.exists(file)) {
            LOGGER.info("[alexdim] {} 不存在（该生物群系在当前 ACC 版本中可能未提供），跳过。", file.getFileName());
            return false;
        }
        try {
            String raw = Files.readString(file, StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(raw).getAsJsonObject();
            if (!root.has(FIELD)) {
                LOGGER.warn("[alexdim] {} 中缺少 {} 字段，跳过（ACC 版本配置格式可能已变化）。",
                        file.getFileName(), FIELD);
                return false;
            }
            if (root.get(FIELD).getAsBoolean()) {
                LOGGER.info("[alexdim] {} 已是关闭状态。", file.getFileName());
                return true;
            }
            root.addProperty(FIELD, true);
            Files.writeString(file, GSON.toJson(root), StandardCharsets.UTF_8);
            LOGGER.info("[alexdim] 已关闭主世界生成：{}（disabled_completely=true）", file.getFileName());
            return true;
        } catch (IOException | IllegalStateException e) {
            LOGGER.warn("[alexdim] 无法修改 {}：{}", file.getFileName(), e.toString());
            return false;
        }
    }
}

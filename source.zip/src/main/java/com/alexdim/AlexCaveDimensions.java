package com.alexdim;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AlexCaveDimensions implements ModInitializer {
    public static final String MOD_ID = "alexdim";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[alexdim] Alex Cave Dimensions 6-in-1 loading...");

        // [1] 在服务端启动前（所有模组构造完成后）自动把 Alex's Caves 的
        //     6 个洞穴生物群系在主世界的生成关闭：
        //     写入 config/alexscaves_biome_generation/<生物群系>.json 的
        //     disabled_completely=true。
        //     - 时机选 SERVER_STARTING：此时 ACC 的配置文件必然已生成
        //       （ACC 在模组初始化阶段创建配置），而世界/区块尚未开始生成，
        //       因此新创建存档或新生成主世界区域时，Alex 洞穴不会再注入主世界，
        //       与 RTF 高度调整、YUNG 洞穴等主世界生成模组完全隔离。
        //     - 生物群系仍保持注册，6 个独立维度可以继续引用它们。
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            LOGGER.info("[alexdim] Server starting, applying Alex's Caves overworld generation disable...");
            AccCaveConfigManager.disableAlexCavesOverworldGeneration();
        });

        // [2] 6 个独立维度由内嵌数据包注册（data/alexdim/dimension/*.json），
        //     - 每个维度使用自定义洞穴噪声（alexdim:worldgen/noise_settings/*.json）
        //       固定单一 Alex 洞穴生物群系（biome_source: fixed），
        //       生物群系的地形/方块/矿物/结构/刷怪/音效/粒子/雾色全部数据驱动生效，
        //       ACC 的专属机制特效（磁力/毒气/失重/辐射/水压）按生物群系 tag 判断，
        //       在固定生物群系的维度中自动触发。
        //     - 维度为原版标准维度（可被 Xaero's World Map / JourneyMap 识别，
        //       维度切换与一键 TP 由地图模组原生支持）。
        LOGGER.info("[alexdim] Ready. 6 cave dimensions: alexdim:{magnetic_caves,primordial_caves,toxic_caves,abyssal_chasm,forlorn_hollows,candy_cavity}");
    }
}

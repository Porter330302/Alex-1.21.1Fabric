package com.alexdim;

import net.minecraft.block.Block;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.Biome;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 依赖完整性守卫：在服务端启动时校验 6 个维度引用的 Alex's Caves 内容
 * （生物群系 + 表面规则方块）是否仍然存在于注册表中。
 *
 * 为什么需要：alexdim 对 AC 的引用全部是数据包字符串 ID。若 Alex's Caves
 * （含 Continued 社区版）更新后删除 / 改名了某个生物群系或方块，维度数据会
 * 引用失效——轻则维度无法进入，重则旧存档中已生成的维度区域在重载时出错。
 * 本守卫在 SERVER_STARTING（世界加载前）完成校验并输出醒目的中文警告，
 * 让玩家在进档之前就知道问题所在，避免带病进入旧存档导致区域损坏。
 *
 * 设计原则：
 *  - 只读校验，绝不修改任何注册表 / 存档数据；
 *  - 缺失时仅输出日志警告，不阻止服务器启动（防止误报导致整个实例起不来）；
 *  - 校验清单与 data/alexdim/worldgen/noise_settings/*.json 及
 *    data/alexdim/dimension/*.json 保持一一对应，修改数据包时须同步本清单。
 */
public final class AccDependencyGuard {
    private static final Logger LOGGER = LoggerFactory.getLogger("alexdim-guard");

    /** 维度 id → 其 biome source 引用的 AC 生物群系（dimension/*.json；caves_all 为 multi_noise 六群系） */
    private static final Map<String, List<String>> DIMENSION_BIOMES;
    /** 维度 id → 其 noise_settings surface_rule 引用的全部方块 */
    private static final Map<String, List<String>> DIMENSION_BLOCKS;

    static {
        DIMENSION_BIOMES = new LinkedHashMap<>();
        DIMENSION_BIOMES.put("magnetic_caves", List.of("alexscaves:magnetic_caves"));
        DIMENSION_BIOMES.put("primordial_caves", List.of("alexscaves:primordial_caves"));
        DIMENSION_BIOMES.put("toxic_caves", List.of("alexscaves:toxic_caves"));
        DIMENSION_BIOMES.put("abyssal_chasm", List.of("alexscaves:abyssal_chasm"));
        DIMENSION_BIOMES.put("forlorn_hollows", List.of("alexscaves:forlorn_hollows"));
        DIMENSION_BIOMES.put("candy_cavity", List.of("alexscaves:candy_cavity"));
        DIMENSION_BIOMES.put("caves_all", List.of(
                "alexscaves:magnetic_caves", "alexscaves:primordial_caves",
                "alexscaves:toxic_caves", "alexscaves:abyssal_chasm",
                "alexscaves:forlorn_hollows", "alexscaves:candy_cavity"));

        DIMENSION_BLOCKS = new LinkedHashMap<>();
        DIMENSION_BLOCKS.put("magnetic_caves", List.of(
                "alexscaves:galena",
                "alexscaves:energized_galena_neutral",
                "alexscaves:scarlet_neodymium_node",
                "alexscaves:azure_neodymium_node",
                "minecraft:bedrock"));
        DIMENSION_BLOCKS.put("primordial_caves", List.of(
                "alexscaves:amber",
                "alexscaves:limestone",
                "minecraft:grass_block",
                "minecraft:dirt",
                "minecraft:bedrock"));
        DIMENSION_BLOCKS.put("toxic_caves", List.of(
                "alexscaves:radrock",
                "alexscaves:unrefined_waste",
                "alexscaves:acid",
                "minecraft:bedrock"));
        DIMENSION_BLOCKS.put("abyssal_chasm", List.of(
                "alexscaves:abyssmarine",
                "alexscaves:muck",
                "minecraft:dirt",
                "minecraft:bedrock"));
        DIMENSION_BLOCKS.put("forlorn_hollows", List.of(
                "alexscaves:coprolith",
                "alexscaves:guano_block",
                "alexscaves:guanostone",
                "alexscaves:porous_coprolith",
                "minecraft:bedrock"));
        DIMENSION_BLOCKS.put("candy_cavity", List.of(
                "alexscaves:block_of_chocolate",
                "alexscaves:block_of_frosted_chocolate",
                "alexscaves:cake_layer",
                "alexscaves:purple_soda",
                "minecraft:bedrock"));
        DIMENSION_BLOCKS.put("caves_all", List.of(
                "alexscaves:galena", "alexscaves:energized_galena_neutral",
                "alexscaves:scarlet_neodymium_node", "alexscaves:azure_neodymium_node",
                "alexscaves:limestone", "alexscaves:amber",
                "alexscaves:radrock", "alexscaves:unrefined_waste", "alexscaves:acid",
                "alexscaves:abyssmarine", "alexscaves:muck",
                "alexscaves:coprolith", "alexscaves:guano_block",
                "alexscaves:guanostone", "alexscaves:porous_coprolith",
                "alexscaves:block_of_chocolate", "alexscaves:block_of_frosted_chocolate",
                "alexscaves:cake_layer", "alexscaves:purple_soda",
                "minecraft:stone", "minecraft:bedrock"));
    }

    private AccDependencyGuard() {
    }

    public static void verify(MinecraftServer server) {
        // 取维度注册表：DynamicRegistryManager.get(RegistryKey) 返回 Registry<T>，
        // 泛型完全匹配（已用 yarn-1.21.1+build.3 映射验证方法签名，无 cast）。
        DynamicRegistryManager regs = server.getRegistryManager();
        Registry<Biome> biomeRegistry = regs.get(RegistryKeys.BIOME);
        Registry<Block> blockRegistry = regs.get(RegistryKeys.BLOCK);

        List<String> missingBiomes = new ArrayList<>();
        List<String> missingBlocks = new ArrayList<>();

        DIMENSION_BIOMES.forEach((dim, biomeIds) -> {
            for (String biomeId : biomeIds) {
                Identifier id = Identifier.tryParse(biomeId);
                if (id == null || !biomeRegistry.containsId(id)) {
                    missingBiomes.add(dim + " -> " + biomeId);
                }
            }
        });

        DIMENSION_BLOCKS.forEach((dim, blockIds) -> {
            for (String blockId : blockIds) {
                Identifier id = Identifier.tryParse(blockId);
                if (id == null || !blockRegistry.containsId(id)) {
                    missingBlocks.add(dim + " -> " + blockId);
                }
            }
        });

        if (missingBiomes.isEmpty() && missingBlocks.isEmpty()) {
            LOGGER.info("[alexdim] 依赖完整性校验通过：6 个维度的 AC 生物群系与全部表面方块均存在。");
            return;
        }

        LOGGER.error("========== [alexdim] 依赖缺失告警 ==========");
        LOGGER.error("[alexdim] 检测到 Alex's Caves（或 Continued 社区版）更新后部分内容 ID 已不存在：");
        if (!missingBiomes.isEmpty()) {
            LOGGER.error("[alexdim] 缺失的生物群系（维度将无法进入）:");
            missingBiomes.forEach(s -> LOGGER.error("[alexdim]   - {}", s));
        }
        if (!missingBlocks.isEmpty()) {
            LOGGER.error("[alexdim] 缺失的方块（对应维度区块生成会失败）:");
            missingBlocks.forEach(s -> LOGGER.error("[alexdim]   - {}", s));
        }
        LOGGER.error("[alexdim] 原因与处理建议：");
        LOGGER.error("[alexdim]   1. 很可能是 Alex's Caves 更新后删改了下述 ID。");
        LOGGER.error("[alexdim]   2. 请勿在旧存档中进入上述缺失维度的区域（已生成区域重载可能出错）。");
        LOGGER.error("[alexdim]   3. 解决办法：更新 alexdim 维度模组至适配新 AC 的版本，或回退 AC 至之前的版本。");
        LOGGER.error("[alexdim]   4. 本守卫只读不改，未修改任何注册表与存档数据。");
        LOGGER.error("=============================================");
    }
}
